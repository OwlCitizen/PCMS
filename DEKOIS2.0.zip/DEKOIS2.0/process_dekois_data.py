#process_schnet_data.py
import os
import warnings
warnings.filterwarnings("ignore")
import Bio
import math
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
from rdkit import Chem
from copy import deepcopy
from rdkit.Chem import AllChem
from Bio.PDB.PDBParser import PDBParser
from torch_geometric.data import Data
from torch_geometric.data import HeteroData
from transformers import T5EncoderModel, T5Tokenizer
from concurrent.futures.thread import ThreadPoolExecutor
from concurrent.futures._base import as_completed

data_path = './'
processed_path = './processed/'

allowable_features = {
    'possible_atomic_num_list' : list(range(1, 119)),
    'possible_formal_charge_list' : [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5],
    'possible_chirality_list' : [
        Chem.rdchem.ChiralType.CHI_UNSPECIFIED,
        Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CW,
        Chem.rdchem.ChiralType.CHI_TETRAHEDRAL_CCW,
        Chem.rdchem.ChiralType.CHI_OTHER
    ],
    'possible_hybridization_list' : [
        Chem.rdchem.HybridizationType.S,
        Chem.rdchem.HybridizationType.SP, Chem.rdchem.HybridizationType.SP2,
        Chem.rdchem.HybridizationType.SP3, Chem.rdchem.HybridizationType.SP3D,
        Chem.rdchem.HybridizationType.SP3D2, Chem.rdchem.HybridizationType.UNSPECIFIED
    ],
    'possible_numH_list' : [0, 1, 2, 3, 4, 5, 6, 7, 8],
    'possible_implicit_valence_list' : [0, 1, 2, 3, 4, 5, 6],
    'possible_degree_list' : [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
}

res_list = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']

num_atom_type = 120 #including the extra mask tokens
num_chirality_tag = 3

num_residue_type = len(res_list)

model_name = "Rostlab/prot_t5_xl_uniref50"
tokenizer = T5Tokenizer.from_pretrained(model_name, do_lower_case=False )
model = T5EncoderModel.from_pretrained(model_name)
model = model.eval()
shift_left = 0
shift_right = -1

def check_left_atoms(left_atoms):
    id_gaps = []
    for i in range(len(left_atoms)-1):
        id_gaps.append(left_atoms[i+1]-left_atoms[i])
    return (max(id_gaps)<=1)

def check_sub_connect(sub, pmol):#, tname):
    #if tname == 'aces' and ((652 in sub and 653 in sub) or (1861 in sub) or (2477 in sub)):
    #    return True
    connect = True
    for aid in sub:
        flag = False
        for bond in pmol.GetAtomWithIdx(aid).GetBonds():
            if bond.GetBeginAtomIdx() == aid and bond.GetEndAtomIdx() in sub:
                flag = True
            elif bond.GetEndAtomIdx() == aid and bond.GetBeginAtomIdx() in sub:
                flag = True
        connect = connect and flag
    return connect

def getSubs(pmol, biors, rd_fasta, tname):
    biordict = {'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E'\
           ,'GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F'\
               ,'PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V','HIP':'H'}
    bioadict = {'H':1, 'C':6, 'N':7, 'O':8, 'S':16}
    subs = []
    aids = []
    atypes = []
    fasta = []
    left_atoms = []
    bior_list = []
    if tname == 'gria2' or tname == 'prgr':
        for r in biors:
            if r.resname in biordict.keys() and len(bior_list)<len(rd_fasta):
                if biordict[r.resname] == rd_fasta[len(bior_list)]:
                    bior_list.append(r)
        biors = bior_list
    for aid in range(len(pmol.GetAtoms())):
        aids.append(aid)
        atypes.append(pmol.GetAtomWithIdx(aid).GetAtomicNum())
    for r in biors:
        if r.resname in biordict.keys():
            notconnected = True
            move_step = 0
            while notconnected:
                aids_o = deepcopy(aids)
                atypes_o = deepcopy(atypes)
                sub = []
                for bioa in r.child_list:
                    if bioa.element=='H':
                        continue
                    if bioadict[bioa.element] in atypes:
                        index = atypes.index(bioadict[bioa.element])
                        sub.append(aids[index])
                        del aids[index]
                        del atypes[index]
                    else:
                        sub = []
                        break
                if not check_sub_connect(sub, pmol) and len(sub)>1:
                    print('Subgraph '+str(len(subs)+1)+' not connected! Moving forward!')
                    aids = deepcopy(aids_o)
                    atypes = deepcopy(atypes_o)
                    left_atoms.append(aids[0])
                    del aids[0]
                    del atypes[0]
                    move_step+=1 
                else:
                    if move_step>0:
                        print('connect after '+str(move_step)+' steps move!')
                    notconnected = False
            if len(fasta)<len(rd_fasta):
                #if rd_fasta[len(fasta)] == biordict[r.resname]:
                subs.append(sub)
                fasta.append(biordict[r.resname])
    #assert len(fasta)==len(rd_fasta)
    return ''.join(fasta), subs, left_atoms+aids

def getSubs_(protein_mol):
    rd_fasta = Chem.MolToFASTA(protein_mol)
    rd_fasta = rd_fasta[rd_fasta.index('\n',0)+1:rd_fasta.index('\n',-1)]
    #print(rd_fasta)
    left_atom = []
    res_dic = {'A': 'C[C@H](N)C(=O)', 'C': 'N[C@@H](CS)C(=O)', 'D': 'N[C@@H](CC(=O)O)C(=O)', 'E': 'N[C@@H](CCC(=O)O)C(=O)', 'F': 'N[C@@H](Cc1ccccc1)C(=O)', 'G': 'NCC(=O)', 'H': 'N[C@@H](Cc1c[nH]cn1)C(=O)', 'I': 'CC[C@H](C)[C@H](N)C(=O)', 'K': 'NCCCC[C@H](N)C(=O)', 'L': 'CC(C)C[C@H](N)C(=O)', 'M': 'CSCC[C@H](N)C(=O)', 'N': 'NC(=O)C[C@H](N)C(=O)', 'P': 'O=C[C@@H]1CCCN1', 'Q': 'NC(=O)CC[C@H](N)C(=O)', 'R': 'N=C(N)NCCC[C@H](N)C(=O)', 'S': 'N[C@@H](CO)C(=O)', 'T': 'C[C@@H](O)[C@H](N)C(=O)', 'V': 'CC(C)[C@H](N)C(=O)', 'W': 'N[C@@H](Cc1c[nH]c2ccccc12)C(=O)', 'Y': 'N[C@@H](Cc1ccc(O)cc1)C(=O)'}
    for i in range(len(protein_mol.GetAtoms())):
        left_atom.append(i)
    res_dict = {}
    for r in res_dic.keys():
        res_dict[r]=list(protein_mol.GetSubstructMatches(Chem.MolFromSmiles(res_dic[r]),useChirality=True))
    subs = []
    #print('prepare finish!')
    for r in rd_fasta:
        #print('processing '+str(r))
        flag_=False
        for sub in res_dict[r]:
            flag = True
            for a in sub:
                if a not in left_atom:
                    flag=False
                    break
            if flag:
                subs.append(list(sub))
                for a in sub:
                    left_atom.remove(a)
                res_dict[r].remove(sub)
                flag_=True
                break
        if not flag_:
            subs.append([])
        #print('finish!')
    return rd_fasta, subs, left_atom

def mol_to_graph_data_obj_ligand(mol, label):
    """
    Converts rdkit mol object to graph Data object required by the pytorch
    geometric package. NB: Uses simplified atom and bond features, and represent
    as indices
    :param mol: rdkit mol object
    :return: graph data object with the attributes: x, edge_index, edge_attr
    """
    
    if str(type(mol))=="<class 'NoneType'>":
        return mol
    
    # atoms
    num_atom_features = 5   # atom type,  chirality tag, x, y, z
    atom_features_list = []
    for ai in range(len(mol.GetAtoms())):
        atom = mol.GetAtoms()[ai]
        atom_feature = [allowable_features['possible_atomic_num_list'].index(
            atom.GetAtomicNum())] + [allowable_features[
            'possible_chirality_list'].index(atom.GetChiralTag())]
        atom_feature += ([mol.GetConformer().GetAtomPosition(ai).x] + [mol.GetConformer().GetAtomPosition(ai).y] + [mol.GetConformer().GetAtomPosition(ai).z])
        atom_features_list.append(atom_feature)
    x = torch.tensor(np.array(atom_features_list))#, dtype=torch.long)
    
    # bonds
    num_bond_features = 4   # direction (x,y,z), distance
    if len(mol.GetBonds()) > 0: # mol has bonds
        edges_list = []
        edge_features_list = []
        for bond in mol.GetBonds():
            i = bond.GetBeginAtomIdx()
            j = bond.GetEndAtomIdx()
            x_i,y_i,z_i=mol.GetConformer().GetAtomPosition(i)
            x_j,y_j,z_j=mol.GetConformer().GetAtomPosition(j)
            dist=math.ceil(math.sqrt((x_i-x_j)**2+(y_i-y_j)**2+(z_i-z_j)**2))
            if dist == 0:
                raise ValueError("Bonds starts and ends from the same atom!")
            edge_feature=[x_j-x_i]+[y_j-y_i]+[z_j-z_i]+[dist]
            edge_feature_=[x_i-x_j]+[y_i-y_j]+[z_i-z_j]+[dist]
            edges_list.append((i, j))
            edge_features_list.append(edge_feature)
            edges_list.append((j, i))
            edge_features_list.append(edge_feature_)
        
        # data.edge_index: Graph connectivity in COO format with shape [2, num_edges]
        edge_index = torch.tensor(np.array(edges_list).T, dtype=torch.long)
        
        # data.edge_attr: Edge feature matrix with shape [num_edges, num_edge_features]
        edge_attr = torch.tensor(np.array(edge_features_list),
                                 dtype=torch.float)
    else:   # mol has no bonds
        edge_index = torch.empty((2, 0), dtype=torch.long)
        edge_attr = torch.empty((0, num_bond_features), dtype=torch.long)
    
    #label_=torch.zeros(2)
    #label_[label]=1
    label=torch.tensor([label])
    data = Data(x=x, y=label, edge_index=edge_index, edge_attr=edge_attr)
    
    return data

def mol_to_graph_data_obj_protein(mol, rd_fasta, biors, tname):
    """
    Converts rdkit mol object to graph Data object required by the pytorch
    geometric package. NB: Uses simplified atom and bond features, and represent
    as indices
    :param mol: rdkit mol object
    :return: graph data object with the attributes: x, edge_index, edge_attr
    """
    
    if str(type(mol))=="<class 'NoneType'>":
        return mol, mol, mol
    
    # atoms
    num_atom_features = 5   # atom type,  chirality tag, x, y, z
    atom_features_list = []
    for ai in range(len(mol.GetAtoms())):
        atom = mol.GetAtoms()[ai]
        atom_feature = [allowable_features['possible_atomic_num_list'].index(
            atom.GetAtomicNum())] + [allowable_features[
            'possible_chirality_list'].index(atom.GetChiralTag())]
        atom_feature += ([mol.GetConformer().GetAtomPosition(ai).x] + [mol.GetConformer().GetAtomPosition(ai).y] + [mol.GetConformer().GetAtomPosition(ai).z])
        atom_features_list.append(atom_feature)
    x = torch.tensor(np.array(atom_features_list))#, dtype=torch.long)
    
    # atom bonds
    num_bond_features = 4   # direction (x,y,z), distance
    if len(mol.GetBonds()) > 0: # mol has bonds
        edges_list = []
        edge_features_list = []
        for bond in mol.GetBonds():
            i = bond.GetBeginAtomIdx()
            j = bond.GetEndAtomIdx()
            x_i,y_i,z_i=mol.GetConformer().GetAtomPosition(i)
            x_j,y_j,z_j=mol.GetConformer().GetAtomPosition(j)
            dist=math.ceil(math.sqrt((x_i-x_j)**2+(y_i-y_j)**2+(z_i-z_j)**2))
            if dist == 0:
                raise ValueError("Bonds starts and ends from the same atom!")
            edge_feature=[x_j-x_i]+[y_j-y_i]+[z_j-z_i]+[dist]
            edge_feature_=[x_i-x_j]+[y_i-y_j]+[z_i-z_j]+[dist]
            edges_list.append((i, j))
            edge_features_list.append(edge_feature)
            edges_list.append((j, i))
            edge_features_list.append(edge_feature_)
        
        # data.edge_index: Graph connectivity in COO format with shape [2, num_edges]
        edge_index = torch.tensor(np.array(edges_list).T, dtype=torch.long)
        
        # data.edge_attr: Edge feature matrix with shape [num_edges, num_edge_features]
        edge_attr = torch.tensor(np.array(edge_features_list),
                                 dtype=torch.float)
    else:   # mol has no bonds
        edge_index = torch.empty((2, 0), dtype=torch.long)
        edge_attr = torch.empty((0, num_bond_features), dtype=torch.long)
    
    #label_=torch.zeros(2)
    #label_[label]=1
    #label=torch.tensor([label])
    #data = Data(x=x, y=label, edge_index=edge_index, edge_attr=edge_attr)
    data = HeteroData()
    data['atom'].x = x
    data['atom', 'bond', 'atom'].edge_index = edge_index
    data['atom', 'bond', 'atom'].edge_attr = edge_attr
    
    rd_fasta, subs, left_atoms = getSubs(mol, biors, rd_fasta, tname)
    assert len(rd_fasta) == len(subs)
    #residue_features_list = []
    edge_list = []#'atom','belong','residue'
    edge_list_ = []#'residue','of','atom'
    residues_edge_list = []#'residue','nextto','residue'
    for r in range(len(rd_fasta)):
        #residue_features_list.append([res_list.index(rd_fasta[r])])
        for a in subs[r]:
            edge_list.append([a,r])
            edge_list_.append([r,a])
        if r>0:
            residues_edge_list.append([r-1, r])
            residues_edge_list.append([r, r-1])
    #data['residue'].x = torch.tensor(np.array(residue_features_list), dtype=torch.long)
    with torch.no_grad():
        ids = tokenizer.batch_encode_plus([list(rd_fasta)], add_special_tokens=True, padding=True, is_split_into_words=True, return_tensors="pt")
        embedding = model(input_ids=ids['input_ids'])[0]
        residue_features = embedding[0].detach()[shift_left:shift_right]
    data['residue'].x = residue_features
    data['atom','belong','residue'].edge_index = torch.tensor(np.array(edge_list).T, dtype=torch.long)
    data['residue','of','atom'].edge_index = torch.tensor(np.array(edge_list_).T, dtype=torch.long)
    data['residue','nextto','residue'].edge_index = torch.tensor(np.array(residues_edge_list).T, dtype=torch.long)
    
    return data, rd_fasta, left_atoms

def process_task(tname, actives, decoys, pdata, rd_fasta, schedule):
    act_count = 0
    dcy_count = 0
    
    pbar = tqdm(actives, desc = 'processing '+tname+'('+schedule+'%) actives')
    for act in pbar:
        act_data=mol_to_graph_data_obj_ligand(act, 1)
        if str(type(act_data))=="<class 'NoneType'>":
            continue
        else:
            torch.save(act_data, processed_path+'data_'+tname+'_active_'+str(act_count)+'.pt')
            act_count+=1
    
    pbar = tqdm(decoys, desc='processing '+tname+'('+schedule+'%) decoys')
    for dcy in pbar:
        dcy_data = mol_to_graph_data_obj_ligand(dcy, 0)
        if str(type(dcy_data))=="<class 'NoneType'>":
            continue
        else:
            torch.save(dcy_data, processed_path+'data_'+tname+'_decoy_'+str(dcy_count)+'.pt')
            dcy_count+=1
    
    return (tname, rd_fasta, pdata, act_count, dcy_count)
    
def main():
    p=PDBParser()
    total = len(list(os.listdir(data_path)))
    error_proteins = []
    protein_with_unseen = []
    atom_lefted_proteins = []
    fcount = 0
    tnames = []
    act_nums = []
    dcy_nums = []
    fastas = []
    left_atoms_nums = []
    protein_file_names = []
    folders = []
    for folder in os.listdir(data_path+'ligands/'):
        name = folder.split('.')[0]
        folders.append(name)
    print('Folders: '+str(folders)+'\n')
    for folder in folders:
        print('processing '+folder+' ...('+str(int(fcount*100/total))+'%)')
        fcount+=1
        tname = folder
        pmol = AllChem.MolFromPDBFile(data_path+'targets/'+tname+'.pdb')
        actives = Chem.SDMolSupplier(data_path+'ligands/'+tname+'.sdf')
        decoys = Chem.SDMolSupplier(data_path+'decoys/'+tname+'_Celling-v1.12_decoyset.sdf')
        
        if pmol == None or tname == 'aces':
            error_proteins.append(tname)
            continue
        rd_fasta = Chem.MolToFASTA(pmol)
        rd_fasta = rd_fasta[rd_fasta.index('\n',0)+1:rd_fasta.index('\n',-1)]
        flag = False
        for r in rd_fasta:
            if r not in res_list:
                flag = True
                break
        if flag:
            protein_with_unseen.append(tname)
            continue
        
        act_count = 0
        dcy_count = 0
        
        pbar = tqdm(actives, desc = 'processing actives')
        for act in pbar:
            act_data=mol_to_graph_data_obj_ligand(act, 1)
            if str(type(act_data))=="<class 'NoneType'>":
                continue
            else:
                torch.save(act_data, processed_path+'data_'+tname+'_active_'+str(act_count)+'.pt')
                act_count+=1
        
        pbar = tqdm(decoys, desc='processing decoys')
        for dcy in pbar:
            dcy_data = mol_to_graph_data_obj_ligand(dcy, 0)
            if str(type(dcy_data))=="<class 'NoneType'>":
                continue
            else:
                torch.save(dcy_data, processed_path+'data_'+tname+'_decoy_'+str(dcy_count)+'.pt')
                dcy_count+=1
        
        print('processing '+tname+' protein ...')
        struct = p.get_structure(tname, data_path+'targets/'+tname+'.pdb')
        pdata, rd_fasta, left_atoms = mol_to_graph_data_obj_protein(pmol, rd_fasta, struct.get_residues(), tname)
        
        if str(type(pdata))=="<class 'NoneType'>":
            print(tname+' protein error!')
            error_proteins.append(tname)
        else:
            fastas.append(rd_fasta)
            tnames.append(tname)
            left_atoms_nums.append(len(left_atoms))
            if len(left_atoms) > 0:
                print(tname+' left atoms:'+str(len(left_atoms)))
                print(rd_fasta)
                atom_lefted_proteins.append(tname)
            act_nums.append(act_count)
            dcy_nums.append(dcy_count)
            torch.save(pdata, processed_path+tname+'_new_protein.pt')
            protein_file_names.append(tname+'_new_protein.pt')
    print('FINISH!')
    
    data_info=pd.DataFrame(act_nums, columns = ['len_active'], index = tnames)
    data_info['len_decoy'] = dcy_nums
    data_info['new_protein_filename'] = protein_file_names
    data_info['fasta'] = fastas
    data_info['left_atom_num'] = left_atoms_nums
    data_info.to_csv(processed_path+'data_info.csv')
    
    print('Error proteins:'+str(error_proteins))
    print('Proteins with unseen residues:'+str(protein_with_unseen))
    print('Atom lefted proteins:'+str(atom_lefted_proteins))

def main_():
    p=PDBParser()
    total = len(list(os.listdir(data_path)))
    error_proteins = []
    protein_with_unseen = []
    atom_lefted_proteins = []
    fcount = 0
    tnames = []
    act_nums = []
    dcy_nums = []
    fastas = []
    left_atoms_nums = []
    protein_file_names = []
    executor = ThreadPoolExecutor(max_workers=5)
    all_threads=[]
    folders = []
    for folder in os.listdir(data_path+'ligands/'):
        name = folder.split('.')[0]
        folders.append(name)
    print('Folders: '+str(folders)+'\n')
    for folder in folders:
        schedule = str(int(fcount*100/total))
        print('processing '+folder+' ...('+schedule+'%)')
        fcount+=1
        tname = folder
        pmol = AllChem.MolFromPDBFile(data_path+'targets/'+tname+'.pdb')
        actives = Chem.SDMolSupplier(data_path+'ligands/'+tname+'.sdf')
        decoys = Chem.SDMolSupplier(data_path+'decoys/'+tname+'_Celling-v1.12_decoyset.sdf')
        
        if pmol == None or tname == 'aces':
            error_proteins.append(tname)
            continue
        rd_fasta = Chem.MolToFASTA(pmol)
        rd_fasta = rd_fasta[rd_fasta.index('\n',0)+1:rd_fasta.index('\n',-1)]
        flag = False
        for r in rd_fasta:
            if r not in res_list:
                flag = True
                break
        if flag:
            protein_with_unseen.append(tname)
            continue
        
        print('processing '+tname+'('+schedule+'%) protein ...')
        struct = p.get_structure(tname, data_path+'targets/'+tname+'.pdb')
        pdata, rd_fasta, left_atoms = mol_to_graph_data_obj_protein(pmol, rd_fasta, struct.get_residues(), tname)
        
        if str(type(pdata))=="<class 'NoneType'>":
            print(tname+' protein error!')
            error_proteins.append(tname)
        else:
            thread = executor.submit(process_task, tname, actives, decoys, pdata, rd_fasta, schedule)
            all_threads.append(thread)
        
    for future in as_completed(all_threads):
        (tname, rd_fasta, pdata, act_count, dcy_count) = future.result()
        fastas.append(rd_fasta)
        tnames.append(tname)
        act_nums.append(act_count)
        dcy_nums.append(dcy_count)
        torch.save(pdata, processed_path+tname+'_new_protein.pt')
        protein_file_names.append(tname+'_new_protein.pt')
    print('FINISH!')
    
    data_info=pd.DataFrame(act_nums, columns = ['len_active'], index = tnames)
    data_info['len_decoy'] = dcy_nums
    data_info['new_protein_filename'] = protein_file_names
    data_info['fasta'] = fastas
    #data_info['left_atom_num'] = left_atoms_nums
    data_info.to_csv(processed_path+'data_info.csv')
    
    print('Error proteins:'+str(error_proteins))
    print('Proteins with unseen residues:'+str(protein_with_unseen))
    print('Atom lefted proteins:'+str(atom_lefted_proteins))

if __name__ == '__main__':
    main_()     
            